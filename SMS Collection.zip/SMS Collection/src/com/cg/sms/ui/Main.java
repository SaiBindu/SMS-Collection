package com.cg.sms.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.sms.dto.Student;
import com.cg.sms.service.StudentService;
import com.cg.sms.service.StudentServiceImpl;

public class Main {
	
	public static void main(String args[]) {
		
		
		//Student student = new Student();
		StudentService service = new StudentServiceImpl();
		
		Scanner sc =  new Scanner(System.in);
		int ch = 0;
		do{
		
		System.out.println("1. Add Student");
		System.out.println("2. Display Student Details");
		System.out.println("3. Update Details Student");
	    System.out.println("4.Remove Student details");
		System.out.println("5. Display Student list");
		System.out.println("6.Exit");
		System.out.println("Enter your choice ");
		ch = sc.nextInt();
		switch(ch) {
		
		case 1:
			
		
			System.out.println("Enter name:");
			String name = sc.next();
			
			System.out.println("Enter Course name:");
			String cname = sc.next();
			
			System.out.println("Enter age:");
			int age = sc.nextInt();
			
			System.out.println("Enter Mobile no:");
			String mob = sc.next();
			
			
			Student student = new Student();
			student.setName(name);
			student.setCourseName(cname);
			student.setAge(age);
			student.setMobileno(mob);
			
			int rn = service.addStudent(student);
			System.out.println("student record added .."+ rn);
		break;
		
		case 2:
			System.out.println("Enter Roll No : ");
			rn = sc.nextInt();
			
			student = service.getStudent(rn);
			if(student == null)
				System.out.println("record not found...");
			else{
			
			
			System.out.println(student.getName());
			System.out.println(student.getAge());
			System.out.println(student.getCourseName());
			System.out.println(student.getMobileno());
			}
		break;
		
		
		case 3:
			System.out.println("Enter roll no");
			rn = sc.nextInt();
			
			student = service.getStudent(rn);
			if(student == null)
				System.out.println("record not found...");
			else{
				System.out.println("Enter new mobile number: ");
				String mobno = sc.next();
				student.setMobileno(mobno);
				student =service.updateStudent(student);
				System.out.println("Record updated");
				
				System.out.println(student.getName());
				System.out.println(student.getMobileno());
			
			
		    }
			break;
		case 4:
			System.out.println("Enter roll no");
			rn = sc.nextInt();
			
			student = service.getStudent(rn);
			if(student == null)
				System.out.println("record not found...");
			else{
			  student =service.removeStudent(rn);
				System.out.println("Record deleted");
				
			}
			
			break;
			
		case 5:
			System.out.println("Enter Course Name");
			cname = sc.next();
			
			ArrayList<Student> list = service.getStudentList(cname);
			
			if(list.size() == 0)
				System.out.println("No student enrolled to this record");
			else {
				for(Student s : list) {
					System.out.println(s.getName()+" "+s.getMobileno());
				}
			}
			break;
		
		
		case 6:
			break;
		
	}
		}
	while(ch!=7);
	
		
	}
}

